#include "main.h"
ASIModule *pSAMP = nullptr;
CHookJmp *HookRPC = nullptr;
void *sourceAddressFunc = nullptr;
typedef void(__cdecl *HookFuncDestruct) (void *);
HookFuncDestruct sourceRakClientDestructor;
DWORD hook_handle_rpc_true = 0, hook_handle_rpc_false = 0;

void __cdecl setup_hook_RakClientDestructor(void *&rakclient) {
	return rakclient == pSAMP->getRaknet() ? sourceRakClientDestructor(rakclient) 
		: (pSAMP->SetRaknetHooks(true) ? pSAMP->SetRaknetHooks(false) : sourceRakClientDestructor(rakclient));
};

void __declspec (naked) setup_hook_incoming_rpc(void) {
	static RPCParameters *pRPCParams = nullptr;
	static RPCNode *pRPCNode = nullptr;
	__asm mov pRPCParams, eax;
	__asm mov pRPCNode, edi;
	if (HandleRPCPacketFunc(pRPCNode->uniqueIdentifier, pRPCParams)) {
		__asm jmp hook_handle_rpc_true;
	}
	else {
		__asm jmp hook_handle_rpc_false;
	}
};

void __cdecl PluginInit(void) {
	DWORD dwSAMP = 0;
	for (; !dwSAMP; dwSAMP = (DWORD)GetModuleHandleA("SAMP.DLL")) {
		Sleep(10);
	}
	pSAMP = new ASIModule(dwSAMP, true);
	while (!pSAMP->Init()) {
		Sleep(100);
	}
	if (pSAMP->GetSAMP()) {
		HookRPC = new CHookJmp(pSAMP->GetHookSAMP(0), setup_hook_incoming_rpc, 0x06);
		hook_handle_rpc_true = HookRPC->GetExitAddress();
		hook_handle_rpc_false = pSAMP->GetHookSAMP(0) + 0x06;
		InstallHook(sourceRakClientDestructor, sourceAddressFunc, (DWORD)pSAMP->GetHookSAMP(1), setup_hook_RakClientDestructor, 0x06);
	}
	return ExitThread(0);
};

BOOL __stdcall DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
	switch (fdwReason) {
		case DLL_PROCESS_DETACH:
			pSAMP->deleteptr(HookRPC);
			UninstallHook((BYTE*)pSAMP->GetHookSAMP(1), 0x06, sourceAddressFunc);
			pSAMP->deleteptr(pSAMP);
			break;
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hinstDLL);
			CreateThread(0, 0, (LPTHREAD_START_ROUTINE)PluginInit, 0, 0, 0);
			break;
	}
	return TRUE;
};