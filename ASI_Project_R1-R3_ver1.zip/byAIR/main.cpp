#include "main.h"
ASIModule *pSAMP = nullptr;
CHookJmp *HookRPC = nullptr;
DWORD hook_handle_rpc_true = 0, hook_handle_rpc_false = 0;

void _declspec (naked) setup_hook_incoming_rpc(void)
{
	static RPCParameters *pRPCParams = nullptr;
	static RPCNode *pRPCNode = nullptr;
	__asm mov pRPCParams, eax;
	__asm mov pRPCNode, edi;
	if (HandleRPCPacketFunc(pRPCNode->uniqueIdentifier, pRPCParams)) {
		__asm jmp hook_handle_rpc_true;
	}
	else {
		__asm jmp hook_handle_rpc_false;
	}
};

void PluginInit(void) {
	DWORD dwSAMP = 0;
	for (; !dwSAMP; dwSAMP = (DWORD)GetModuleHandleA("SAMP.DLL")) {
		Sleep(10);
	}
	pSAMP = new ASIModule(dwSAMP, true);
	while (!pSAMP->Init()) {
		Sleep(100);
	}
	if (pSAMP->GetSAMP()) {
		HookRPC = new CHookJmp(pSAMP->GetHookSAMP(), setup_hook_incoming_rpc, 0x06);
		hook_handle_rpc_true = HookRPC->GetExitAddress();
		hook_handle_rpc_false = pSAMP->GetHookSAMP() + 0x06;
	}
	return ExitThread(0);
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
	switch (fdwReason) {
		case DLL_PROCESS_DETACH:
			if (HookRPC != nullptr) {
				pSAMP->delete_hook(HookRPC);
			}
			if (pSAMP != nullptr) {
				pSAMP->delete_hook(pSAMP);
			}
			break;
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hinstDLL);
			CreateThread(0, 0, (LPTHREAD_START_ROUTINE)PluginInit, 0, 0, 0);
			break;
	}
	return TRUE;
};