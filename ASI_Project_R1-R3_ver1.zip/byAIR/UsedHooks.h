#pragma once
#include "main.h"
typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;

class CMemCpy
{
public:
	CMemCpy(void *dest, const void *src, size_t stLen, bool needRestore = true)
	{
		_backup = new byte[stLen];
		memcpy_safe(_backup, dest, stLen);
		memcpy_safe(dest, src, stLen);
		_dest = dest;
		_stLen = stLen;
		_needRestore = needRestore;
	}
	CMemCpy(DWORD dest, const void *src, size_t stLen, bool needRestore = true)
	{
		_backup = new byte[stLen];
		memcpy_safe(_backup, (void*)dest, stLen);
		memcpy_safe((void*)dest, src, stLen);
		_dest = (void*)dest;
		_stLen = stLen;
		_needRestore = needRestore;
	}
	CMemCpy(void *dest, DWORD src, size_t stLen, bool needRestore = true)
	{
		_backup = new byte[stLen];
		memcpy_safe(_backup, dest, stLen);
		memcpy_safe(dest, (void*)src, stLen);
		_dest = dest;
		_stLen = stLen;
		_needRestore = needRestore;
	}
	CMemCpy(DWORD dest, DWORD src, size_t stLen, bool needRestore = true)
	{
		_backup = new byte[stLen];
		memcpy_safe(_backup, (void*)dest, stLen);
		memcpy_safe((void*)dest, (void*)src, stLen);
		_dest = (void*)dest;
		_stLen = stLen;
		_needRestore = needRestore;
	}

	int CmpDest(void *mem)
	{
		return memcmp_safe(_dest, mem, _stLen);
	}
	int CmpDest(DWORD mem)
	{
		return memcmp_safe(_dest, (void*)mem, _stLen);
	}

	int CmpSrc(void *mem)
	{
		return memcmp_safe(_backup, mem, _stLen);
	}
	int CmpSrc(DWORD mem)
	{
		return memcmp_safe(_backup, (void*)mem, _stLen);
	}

	virtual ~CMemCpy()
	{
		if (_needRestore)
			memcpy_safe(_dest, _backup, _stLen);
		delete[] _backup;
	}
protected:
	void *memcpy_safe(void *dest, const void *src, size_t stLen)
	{
		if (dest == nullptr || src == nullptr || stLen == 0)
			return nullptr;

		MEMORY_BASIC_INFORMATION	mbi;
		VirtualQuery(dest, &mbi, sizeof(mbi));
		VirtualProtect(mbi.BaseAddress, mbi.RegionSize, PAGE_EXECUTE_READWRITE, &mbi.Protect);

		void	*pvRetn = memcpy(dest, src, stLen);
		VirtualProtect(mbi.BaseAddress, mbi.RegionSize, mbi.Protect, &mbi.Protect);
		FlushInstructionCache(GetCurrentProcess(), dest, stLen);
		return pvRetn;
	}
private:
	void *_dest;
	size_t _stLen;
	byte* _backup;

	bool _needRestore;

	int memcmp_safe(const void *_s1, const void *_s2, uint32_t len)
	{
		const uint8_t	*s1 = (const uint8_t *)_s1;
		const uint8_t	*s2 = (const uint8_t *)_s2;
		uint8_t			buf[4096];

		for (;;)
		{
			if (len > 4096)
			{
				if (!memcpy_safe(buf, s1, 4096))
					return 0;
				if (memcmp(buf, s2, 4096))
					return 0;
				s1 += 4096;
				s2 += 4096;
				len -= 4096;
			}
			else
			{
				if (!memcpy_safe(buf, s1, len))
					return 0;
				if (memcmp(buf, s2, len))
					return 0;
				break;
			}
		}

		return 1;
	}
};
class CMemSet : public CMemCpy
{
public:
	CMemSet(void *dest, int c, size_t Len, bool needRestore = true) : CMemCpy(dest, nullptr, Len, needRestore)
	{
		memset_safe(dest, c, Len);
	}
	CMemSet(DWORD dest, int c, size_t Len, bool needRestore = true) : CMemCpy(dest, nullptr, Len, needRestore)
	{
		memset_safe((void*)dest, c, Len);
	}
private:
	int memset_safe(void *_dest, int c, DWORD len)
	{
		byte *dest = (byte *)_dest;
		byte buf[4096];
		memset(buf, c, (len > 4096) ? 4096 : len);
		for (;;)
		{
			if (len > 4096)
			{
				if (!memcpy_safe(dest, buf, 4096))
					return 0;
				dest += 4096;
				len -= 4096;
			}
			else
			{
				if (!memcpy_safe(dest, buf, len))
					return 0;
				break;
			}
		}
		return 1;
	}
};

struct stFindPatern
{
	DWORD dwAddress;
	DWORD dwLen;
	BYTE *bMask;
	char *szMask;
};

class CVirtualCode
{
public:
	CVirtualCode(void* src, size_t origLen, bool originalBeforeCode, void* code, size_t len, bool SafeVirtual = false)
	{
		_src = src;
		_code = code;
		_origLen = origLen;
		_len = len;
		_isBefore = originalBeforeCode;
		_SafeVirtual = SafeVirtual;
		MemSet_orig = nullptr;

		if (_origLen < 5)
			return;

		_virtualAddr = VirtualAlloc(NULL, origLen + len + 5, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		memset(_virtualAddr, 0x90, origLen + len + 5);
		_origAddr = (DWORD)_virtualAddr + (!_isBefore ? len : 0);
		MemCpy_orig = new CMemCpy(_origAddr, src, origLen, false);
		ModifyCode();
		MemSet = new CMemSet(src, 0x90, origLen, false);
		_codeAddr = (DWORD)_virtualAddr + (_isBefore ? _origLen : 0);
		MemCpy_code = new CMemCpy(_codeAddr, code, len, false);
		CMemSet *asmJmp = new CMemSet(src, 0xE9, 1, false);
		DWORD RelativeAddress = GetRelativeAddress((DWORD)src, (DWORD)_virtualAddr);
		asmJmpAddr = new CMemCpy((DWORD)src + 1, &RelativeAddress, 4, false);
		asmJmpExit = new CMemSet((DWORD)_virtualAddr + origLen + len, 0xE9, 1, false);
		RelativeAddress = GetRelativeAddress((DWORD)_virtualAddr + origLen + len, (DWORD)src + origLen);
		asmJmpExitAddr = new CMemCpy((DWORD)_virtualAddr + origLen + len + 1, &RelativeAddress, 4, false);
	}
	CVirtualCode(stFindPatern src_base, void* src, size_t origLen, bool originalBeforeCode, void* code, size_t len, bool SafeVirtual = false)
	{
		src = (void*)((DWORD)src + FindPattern(src_base.dwAddress, src_base.dwLen, src_base.bMask, src_base.szMask));
		delete[] src_base.bMask;
		delete[] src_base.szMask;
		_src = src;
		_code = code;
		_origLen = origLen;
		_len = len;
		_isBefore = originalBeforeCode;
		_SafeVirtual = SafeVirtual;
		MemSet_orig = nullptr;
		if (_origLen < 5)
			return;
		_virtualAddr = VirtualAlloc(NULL, origLen + len + 5, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		memset(_virtualAddr, 0x90, origLen + len + 5);
		_origAddr = (DWORD)_virtualAddr + (!_isBefore ? len : 0);
		MemCpy_orig = new CMemCpy(_origAddr, src, origLen, false);
		ModifyCode();
		MemSet = new CMemSet(src, 0x90, origLen, false);
		_codeAddr = (DWORD)_virtualAddr + (_isBefore ? _origLen : 0);
		MemCpy_code = new CMemCpy(_codeAddr, code, len, false);
		CMemSet *asmJmp = new CMemSet(src, 0xE9, 1, false);
		DWORD RelativeAddress = GetRelativeAddress((DWORD)src, (DWORD)_virtualAddr);
		asmJmpAddr = new CMemCpy((DWORD)src + 1, &RelativeAddress, 4, false);
		asmJmpExit = new CMemSet((DWORD)_virtualAddr + origLen + len, 0xE9, 1, false);
		RelativeAddress = GetRelativeAddress((DWORD)_virtualAddr + origLen + len, (DWORD)src + origLen);
		asmJmpExitAddr = new CMemCpy((DWORD)_virtualAddr + origLen + len + 1, &RelativeAddress, 4, false);
	}
	CVirtualCode(DWORD TableDx9Id, size_t origLen, bool originalBeforeCode, void* code, size_t len, bool SafeVirtual = false)
	{
		static DWORD* vtbl = 0, table;
		table = FindPattern((DWORD)GetModuleHandle("d3d9.dll"), 0x128000, (PBYTE)"\xC7\x06\x00\x00\x00\x00\x89\x86\x00\x00\x00\x00\x89\x86", "xx????xx????xx");
		memcpy(&vtbl, (void*)(table + 2), 4);
		void *src = (void*)vtbl[TableDx9Id];
		_src = src;
		_code = code;
		_origLen = origLen;
		_len = len;
		_isBefore = originalBeforeCode;
		_SafeVirtual = SafeVirtual;
		MemSet_orig = nullptr;
		if (_origLen < 5)
			return;
		_virtualAddr = VirtualAlloc(NULL, origLen + len + 5, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		memset(_virtualAddr, 0x90, origLen + len + 5);
		_origAddr = (DWORD)_virtualAddr + (!_isBefore ? len : 0);
		MemCpy_orig = new CMemCpy(_origAddr, src, origLen, false);
		ModifyCode();
		MemSet = new CMemSet(src, 0x90, origLen, false);
		_codeAddr = (DWORD)_virtualAddr + (_isBefore ? _origLen : 0);
		MemCpy_code = new CMemCpy(_codeAddr, code, len, false);
		CMemSet *asmJmp = new CMemSet(src, 0xE9, 1, false);
		DWORD RelativeAddress = GetRelativeAddress((DWORD)src, (DWORD)_virtualAddr);
		asmJmpAddr = new CMemCpy((DWORD)src + 1, &RelativeAddress, 4, false);
		asmJmpExit = new CMemSet((DWORD)_virtualAddr + origLen + len, 0xE9, 1, false);
		RelativeAddress = GetRelativeAddress((DWORD)_virtualAddr + origLen + len, (DWORD)src + origLen);
		asmJmpExitAddr = new CMemCpy((DWORD)_virtualAddr + origLen + len + 1, &RelativeAddress, 4, false);
	}

	void NopOriginalCode(bool nop)
	{
		if (nop && MemSet_orig == nullptr)
			MemSet_orig = new CMemSet(_origAddr, 0x90, _origLen);
		else if ( !nop && MemSet_orig != nullptr ){
			delete MemSet_orig;
			MemSet_orig = NULL;
		}
	}

	virtual ~CVirtualCode()
	{
		if (_origLen < 5)
			return;
		delete MemCpy_code;
		NopOriginalCode(false);

		if ( !_SafeVirtual ) {
			delete MemCpy_orig;
			delete asmJmpAddr;
			delete asmJmp;
			delete asmJmpExitAddr;
			delete asmJmpExit;
			delete MemSet;
			VirtualFree(_virtualAddr, _origLen + _len + 5, MEM_RELEASE);
		} else {
			memset((void*)_codeAddr, 0x90, _len);
			if (_len > 5){
				*(byte*)_codeAddr = 0xE9; //jmp
				DWORD RelativeAddress = GetRelativeAddress(_codeAddr, _origAddr);
				memcpy((void*)(_codeAddr + 1), &RelativeAddress, 4);
			}
		}
	}
protected:
	DWORD _codeAddr;
	CMemCpy *MemCpy_code;

	DWORD GetRelativeAddress(DWORD dwFrom /*hook addr*/, DWORD dwTo /*func addr*/)
	{
		return dwTo - (dwFrom + 5);
	}
	bool bCompare(const BYTE* pData, const BYTE* bMask, const char* szMask)
	{
		for (; *szMask; ++szMask, ++pData, ++bMask)
			if (*szMask == 'x' && *pData != *bMask)
				return false;

		return (*szMask) == NULL;
	}
	DWORD FindPattern(DWORD dwAddress, DWORD dwLen, BYTE *bMask, char * szMask)
	{
		for (DWORD i = 0; i < dwLen; i++)
			if (bCompare((BYTE*)(dwAddress + i), bMask, szMask))
				return (DWORD)(dwAddress + i);

		return 0;
	}
private:
	void* _virtualAddr;
	void* _src;
	void* _code;

	size_t _origLen;
	size_t _len;

	bool _isBefore;
	bool _SafeVirtual;

	DWORD _origAddr;

	CMemCpy *MemCpy_orig;
	CMemCpy *asmJmpAddr;
	CMemCpy *asmJmpExitAddr;
	CMemSet *asmJmp;
	CMemSet *asmJmpExit;
	CMemSet *MemSet;
	CMemSet *MemSet_orig;

	void ModifyCode()
	{
		if (_origLen < 5)
			return;
		DWORD VirtualCode = (DWORD)_virtualAddr + (!_isBefore ? _len : 0);
		if (*(byte*)VirtualCode != 0xE8 && *(byte*)VirtualCode != 0xE9)
			return;

		DWORD dwRelative = *(DWORD*)(VirtualCode + 1);
		DWORD dwFunc = GetFuncAddress((DWORD)_src, dwRelative);
		dwRelative = GetRelativeAddress(VirtualCode, dwFunc);
		memcpy((void*)(VirtualCode + 1), &dwRelative, 4);
	}
	DWORD GetFuncAddress(DWORD dwFrom /*hook addr*/, DWORD dwRelative /*To addr*/)
	{
		return dwRelative + (dwFrom + 5);
	}
};

class CHookJmp : public CVirtualCode
{
public:
	CHookJmp(void* addrForHook, void(* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode(addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90", 5, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize(addrForHook, pFunc);
	}
	CHookJmp(DWORD addrForHook, void(* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode((void*)addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90", 5, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize((void*)addrForHook, pFunc);
	}
	CHookJmp(DWORD addrForHook, void(*pFunc)(void *&), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode((void*)addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90", 5, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize((void*)addrForHook, pFunc);
	}
	DWORD GetExitAddress()
	{
		return _codeAddr + 5;
	}
private:
	void Initialize(void* addrForHook, void(*pFunc)())
	{
		delete MemCpy_code;
		byte code[5];
		code[0] = 0xE9; //jmp
		DWORD RelativeAddress = GetRelativeAddress(_codeAddr, (DWORD)pFunc);
		MemCpy_code = new CMemCpy((DWORD)code + 1, &RelativeAddress, 4, false);
		delete MemCpy_code;
		MemCpy_code = new CMemCpy(_codeAddr, code, 5, false);
	}
	void Initialize(void* addrForHook, void(*pFunc)(void *&))
	{
		delete MemCpy_code;
		byte code[5];
		code[0] = 0xE9; //jmp
		DWORD RelativeAddress = GetRelativeAddress(_codeAddr, (DWORD)pFunc);
		MemCpy_code = new CMemCpy((DWORD)code + 1, &RelativeAddress, 4, false);
		delete MemCpy_code;
		MemCpy_code = new CMemCpy(_codeAddr, code, 5, false);
	}
};

class CHookCall : public CVirtualCode
{
public:
	CHookCall(void* addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode(addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90\x90\x90", 7, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize(addrForHook, pFunc);
	}
	CHookCall(DWORD addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode((void*)addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90\x90\x90", 7, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize((void*)addrForHook, pFunc);
	}
private:
	void Initialize(void* addrForHook, void(CALLBACK* pFunc)())
	{
		delete MemCpy_code;
		byte code[7];
		code[0] = 0x9C; //pushfd
		code[1] = 0xE8; //call
		code[6] = 0x9D; //popfd
		DWORD RelativeAddress = GetRelativeAddress(_codeAddr + 1, (DWORD)pFunc);
		MemCpy_code = new CMemCpy((DWORD)code + 2, &RelativeAddress, 4, false);
		delete MemCpy_code;
		MemCpy_code = new CMemCpy(_codeAddr, code, 7, false);
	}
};

class CHookCallSafe : public CVirtualCode
{
public:
	CHookCallSafe(void* addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode(addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90\x90\x90\x90\x90", 9, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize(addrForHook, pFunc);
	}
	CHookCallSafe(DWORD addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode((void*)addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90\x90\x90\x90\x90", 9, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize((void*)addrForHook, pFunc);
	}
private:
	void Initialize(void* addrForHook, void(CALLBACK* pFunc)())
	{
		delete MemCpy_code;
		byte code[9];
		code[0] = 0x60; //pushad
		code[1] = 0x9C; //pushfd
		code[2] = 0xE8; //call
		code[7] = 0x9D; //popfd
		code[8] = 0x61; //popad
		DWORD RelativeAddress = GetRelativeAddress(_codeAddr + 2, (DWORD)pFunc);
		MemCpy_code = new CMemCpy((DWORD)code + 3, &RelativeAddress, 4, false);
		delete MemCpy_code;
		MemCpy_code = new CMemCpy(_codeAddr, code, 9, false);
	}
};

class CHookCallNoSafe : public CVirtualCode
{
public:
	CHookCallNoSafe(void* addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode(addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90", 5, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize(addrForHook, pFunc);
	}
	CHookCallNoSafe(DWORD addrForHook, void(CALLBACK* pFunc)(), size_t size = 5, bool CodeBefore = false)
		: CVirtualCode((void*)addrForHook, size, CodeBefore, (byte*)"\x90\x90\x90\x90\x90", 5, (size < 5 ? false : true))
	{
		if (size < 5)
			return;
		Initialize((void*)addrForHook, pFunc);
	}
private:
	void Initialize(void* addrForHook, void(CALLBACK* pFunc)())
	{
		delete MemCpy_code;
		byte code[5];
		code[1] = 0xE8; //call
		DWORD RelativeAddress = GetRelativeAddress(_codeAddr, (DWORD)pFunc);
		MemCpy_code = new CMemCpy((DWORD)code + 1, &RelativeAddress, 4, false);
		delete MemCpy_code;
		MemCpy_code = new CMemCpy(_codeAddr, code, 5, false);
	}
};

void *CreateHook(BYTE *src, const BYTE *dst, int len) {
	if (len < 5) len = 5;
	BYTE *jmp;
	DWORD dwback, jumpto, newjump;
	VirtualProtect(src, len, PAGE_READWRITE, &dwback);
	if (src[0] == 0xE9) {
		jmp = (BYTE*)malloc(10);
		jumpto = (*(DWORD*)(src + 1)) + ((DWORD)src) + 5;
		newjump = (jumpto - (DWORD)(jmp + 5));
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = newjump;
		jmp += 5;
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = (DWORD)(src - jmp);
	}
	else {
		jmp = (BYTE*)malloc(5 + len);
		memcpy(jmp, src, len);
		jmp += len;
		jmp[0] = 0xE9;
		*(DWORD*)(jmp + 1) = (DWORD)(src + len - jmp) - 5;
	}
	src[0] = 0xE9;
	*(DWORD*)(src + 1) = (DWORD)(dst - src) - 5;
	for (int i = 5; i < len; i++) src[i] = 0x90;
	VirtualProtect(src, len, dwback, &dwback);
	return (jmp - len);
};

template<typename T>bool InstallHook(T &Func, void *&Source, DWORD HookFunc, void *SendFunc, const int len) {
	Func = (T)(HookFunc);
	Source = CreateHook((BYTE*)HookFunc, (BYTE*)SendFunc, len);
	if (Source != nullptr) {
		Func = (T)Source;
		return true;
	}
	return false;
};

void UninstallHook(BYTE *src, const int len, void *jmp) {
	if (jmp != nullptr) {
		DWORD dwback;
		VirtualProtect(src, len, PAGE_READWRITE, &dwback);
		memcpy(src, jmp, len);
		VirtualProtect(src, len, dwback, &dwback);
		free(jmp);
	}
	return;
};