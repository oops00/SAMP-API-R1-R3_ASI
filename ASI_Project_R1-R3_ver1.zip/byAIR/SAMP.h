#pragma once
#include "main.h"
#pragma pack(push, 1)

struct stPools_R1 
{
	void									*m_pActor;
	void									*m_pObject;
	void									*m_pGangZone;
	void									*m_pLabel;
	void									*m_pTextdraw;
	void									*m_pMenu;
	void									*m_pPlayer;
	void									*m_pVehicle;
	void									*m_pPickup;
};

struct stPools_R3
{
	void									*m_pMenu;
	void									*m_pActor;
	void									*m_pPlayer;
	void									*m_pVehicle;
	void									*m_pPickup;
	void									*m_pObject;
	void									*m_pGangZone;
	void									*m_pLabel;
	void									*m_pTextdraw;
};

struct stSAMP_R1
{
	void									*pUnk0;
	void									*pServerInfo;
	uint8_t									byteSpace[24];
	char									m_szHostAddress[257];
	char									m_szHostname[259];
	bool									bNametagStatus;
	uint32_t								m_nPort;
	uint32_t								ulMapIcons[100];
	int										iLanMode;
	int										iGameState;
	uint32_t								ulConnectTick;
	void									*pSettings;
	RakClientInterface						*pRakClientInterface;
	struct stPools_R1						*pPools;
};

struct stSAMP_R3
{
	char									pad_0[44];
	RakClientInterface						*pRakClientInterface;
	char									m_szHostAddress[257];
	char									m_szHostname[257];
	bool									m_bDisableCollision;
	bool									m_bUpdateCameraTarget;
	bool									m_bNametagStatus;
	int										m_nPort;
	BOOL									m_bLanMode;
	uint32_t								ulMapIcons[100];
	int										iGameState;
	uint32_t								ulConnectTick;
	void									*pSettings;
	char									pad_2[5];
	struct stPools_R3						*pPools;
};

struct stChatEntry
{
	__int32									m_timestamp;
	char									m_szPrefix[28];
	char									m_szText[144];
	char									unused[64];
	int										m_nType;
	D3DCOLOR								m_textColor;
	D3DCOLOR								m_prefixColor;
};

struct stChatInfo_R1
{
	int										pagesize;
	void									*pUnk;
	int										iChatWindowMode;
	uint8_t									bTimestamps;
	uint32_t								iLogFileExist;
	char									logFilePathChatLog[MAX_PATH + 1];
	void									*pGameUI;
	void									*pEditBackground;
	void									*pDXUTScrollBar;
	D3DCOLOR								clTextColor;
	D3DCOLOR								clInfoColor;
	D3DCOLOR								clDebugColor;
	uint32_t								ulChatWindowBottom;

	struct stChatEntry						chatEntry[100];

	void									*m_pFontRenderer;
	ID3DXSprite								*m_pChatTextSprite;
	ID3DXSprite								*m_pSprite;
	IDirect3DDevice9						*m_pD3DDevice;
	int										m_iRenderMode; // 0 - Direct Mode (slow), 1 - Normal mode
	ID3DXRenderToSurface					*pID3DXRenderToSurface;
	IDirect3DTexture9						*m_pTexture;
	IDirect3DSurface9						*pSurface;
	D3DDISPLAYMODE							*pD3DDisplayMode;
	int										iUnk1[3];
	int										iUnk2;
	int										m_iRedraw;
	int										m_nPrevScrollBarPosition;
	int										m_iFontSizeY;
	int										m_iTimestampWidth;
};

struct stChatInfo_R3
{
	unsigned int							m_nPageSize;
	char*									m_szLastMessage;
	int										m_nMode;
	bool									m_bTimestamps;
	BOOL									m_bDoesLogExist;
	char									m_szLogPath[261]; // MAX_PATH(+1)
	void									*m_pGameUi;
	void									*m_pEditbox;
	void									*m_pScrollbar;
	D3DCOLOR								m_textColor;
	D3DCOLOR								m_infoColor;
	D3DCOLOR								m_debugColor;
	long									m_nWindowBottom;

	struct stChatEntry						chatEntry[100];

	void									*m_pFontRenderer;
	ID3DXSprite								*m_pChatTextSprite;
	ID3DXSprite								*m_pSprite;
	IDirect3DDevice9						*m_pD3DDevice;
	BOOL									m_bRenderToSurface;
	ID3DXRenderToSurface					*pID3DXRenderToSurface;
	IDirect3DTexture9						*m_pTexture;
	IDirect3DSurface9						*pSurface;
#ifdef _d3d9TYPES_H_
	D3DDISPLAYMODE							m_displayMode;
#else
	unsigned int							m_displayMode[4];
#endif
	int										pad_[2];
	BOOL									m_bRedraw;
	long									m_nScrollbarPos;
	long									m_nCharHeight;
	long									m_nTimestampWidth;
};

typedef void(__cdecl *CMDPROC) (PCHAR);
struct stInputInfo
{
	void									*pD3DDevice;
	void									*pDXUTDialog;
	void									*pDXUTEditBox;
	CMDPROC									pCMDs[144];
	char									szCMDNames[144][33];
	int										iCMDCount;
	int										iInputEnabled;
	char									szInputBuffer[129];
	char									szRecallBufffer[10][129];
	char									szCurrentBuffer[129];
	int										iCurrentRecall;
	int										iTotalRecalls;
	CMDPROC									pszDefaultCMD;
};
#pragma pack(pop)

class IniFile
{
public:
	IniFile(std::string ini_file_name, std::string ini_file_path, bool bcreate = true) {
		m_sIniFileName = ini_file_name;
		if (ini_file_path.empty())
			m_sIniFilePath = getWorkingDirectory();
		else
		{
			createDirectory(ini_file_path);
			m_sIniFilePath = ini_file_path;
		}
		if (bcreate)
			create_new_ini_file();
	};

	~IniFile() {};

	bool deleteIniFile() {
		if (ini_file_exist()) {
			remove(getIniFileFullPath().c_str());
			return true;
		}
		return false;
	};

	std::string	getIniFileName() {
		return m_sIniFileName;
	};

	std::string	getIniFilePath() {
		return m_sIniFilePath;
	};

	std::string	getIniFileFullPath() {
		return m_sIniFilePath + m_sIniFileName;
	};

	std::string getWorkingDirectory() {
		char ppath[MAX_PATH];
		GetCurrentDirectory(MAX_PATH, ppath);
		return std::string(ppath) + "\\";
	};

	std::string createDirectory(std::string ini_file_directory) {
		size_t first_splash = ini_file_directory.find_first_of('\\'), next_splash = std::string::npos;
		std::string dir = ini_file_directory.substr(0, first_splash);
		ini_file_directory = ini_file_directory.substr(first_splash, ini_file_directory.length());
		while ((next_splash = ini_file_directory.find("\\", 1)) != std::string::npos)
		{
			dir = dir + ini_file_directory.substr(0, next_splash);
			ini_file_directory = ini_file_directory.substr(next_splash, ini_file_directory.length());
			CreateDirectory(dir.c_str(), NULL);
		}
		return dir + "\\";
	};

	bool existSection(std::string section_name) {
		DWORD asd = GetPrivateProfileString(section_name.c_str(), NULL, "", szBuffer, 3000, getIniFileFullPath().c_str());
		return (asd > 0) ? true : false;
	};

	std::vector <std::string> readSections() {
		int sections_count = ::GetPrivateProfileSectionNames(szBuffer, 3000, getIniFileFullPath().c_str());
		for (int i = 0; i < sections_count; i++)
			if (szBuffer[i] == '\0') szBuffer[i] = '\\';

		std::string sBuffer = szBuffer;
		std::vector <std::string> sections;
		size_t first_splash = 0, next_splash = std::string::npos;
		while ((next_splash = sBuffer.find_first_of('\\')) != std::string::npos)
		{
			sections.push_back(sBuffer.substr(first_splash, next_splash));
			sBuffer = sBuffer.substr(next_splash + 1, sBuffer.length());
		}
		return sections;
	};

	void deleteSection(std::string section_name) {
		WritePrivateProfileString(section_name.c_str(), NULL, NULL, getIniFileFullPath().c_str());
	};

	bool existKey(std::string section_name, std::string key_name) {
		DWORD asd = GetPrivateProfileString(section_name.c_str(), key_name.c_str(), "", szBuffer, 3000, getIniFileFullPath().c_str());
		return (asd > 0) ? true : false;
	};

	std::vector <std::string> readKeys(std::string section_name) {
		int keys_count = ::GetPrivateProfileSection(section_name.c_str(), szBuffer, 3000, getIniFileFullPath().c_str());
		for (int i = 0; i < keys_count; i++)
			if (szBuffer[i] == '\0') szBuffer[i] = '\\';

		std::string sBuffer = szBuffer;
		std::vector <std::string> keys;
		size_t first_splash = 0, next_splash = std::string::npos;
		while ((next_splash = sBuffer.find_first_of('\\')) != std::string::npos)
		{
			keys.push_back(sBuffer.substr(first_splash, next_splash));
			sBuffer = sBuffer.substr(next_splash + 1, sBuffer.length());
		}
		for (size_t i = 0; i < keys.size(); i++)
			keys[i] = keys[i].substr(0, keys[i].find_first_of('='));

		return keys;
	};

	void deleteKey(std::string section_name, std::string key_name) {
		WritePrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, getIniFileFullPath().c_str());
	};

	int IniFile::getInteger(std::string section_name, std::string key_name) {
		if (!ini_file_exist() || !existSection(section_name) || !existKey(section_name, key_name))
			return 0x7FFFFFFF;

		return GetPrivateProfileInt(section_name.c_str(), key_name.c_str(), 0, getIniFileFullPath().c_str());
	};

	float IniFile::getFloat(std::string section_name, std::string key_name) {
		if (!ini_file_exist() || !existSection(section_name) || !existKey(section_name, key_name))
			return 0.0f;

		GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
		return std::stof(szBuffer);
	};

	std::string IniFile::getString(std::string section_name, std::string key_name) {
		if (!ini_file_exist() || !existSection(section_name) || !existKey(section_name, key_name))
			return "";

		GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
		return szBuffer;
	};

	bool IniFile::getBoolean(std::string section_name, std::string key_name) {
		if (!ini_file_exist() || !existSection(section_name) || !existKey(section_name, key_name))
			return false;

		GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
		if (_stricmp("true", szBuffer) == 0 || _stricmp("1", szBuffer) == 0) return true;
		return false;
	};

	std::vector <std::string> getArrayString(std::string section_name, std::string key_name) {
		int keys_count = ::GetPrivateProfileSection(section_name.c_str(), szBuffer, 3000, getIniFileFullPath().c_str());
		for (int i = 0; i < keys_count; i++)
			if (szBuffer[i] == '\0') szBuffer[i] = '\\';

		std::string sBuffer = szBuffer, szBuff;
		std::vector <std::string> keys_value;
		size_t first_splash = 0, next_splash = std::string::npos, unk = std::string::npos;
		while ((next_splash = sBuffer.find_first_of('\\')) != std::string::npos)
		{
			unk = sBuffer.find_first_of('=');
			szBuff = sBuffer.substr(first_splash, unk);
			if (!strcmp(szBuff.c_str(), key_name.c_str()))
				keys_value.push_back(sBuffer.substr(unk + 1, next_splash - unk - 1));
			sBuffer = sBuffer.substr(next_splash + 1, sBuffer.length());
		}

		return keys_value;
	};

	std::vector <int> getArrayInt(std::string section_name, std::string key_name) {
		int keys_count = ::GetPrivateProfileSection(section_name.c_str(), szBuffer, 3000, getIniFileFullPath().c_str());
		for (int i = 0; i < keys_count; i++)
			if (szBuffer[i] == '\0') szBuffer[i] = '\\';

		std::string sBuffer = szBuffer, szBuff;
		std::vector <int> keys_int_value;
		size_t first_splash = 0, next_splash = std::string::npos, unk = std::string::npos;
		while ((next_splash = sBuffer.find_first_of('\\')) != std::string::npos)
		{
			unk = sBuffer.find_first_of('=');
			szBuff = sBuffer.substr(first_splash, unk);
			if (!strcmp(szBuff.c_str(), key_name.c_str()))
				keys_int_value.push_back(atoi(sBuffer.substr(unk + 1, next_splash - unk - 1).c_str()));
			sBuffer = sBuffer.substr(next_splash + 1, sBuffer.length());
		}

		return keys_int_value;
	};

	std::vector <float> getArrayFloat(std::string section_name, std::string key_name) {
		int keys_count = ::GetPrivateProfileSection(section_name.c_str(), szBuffer, 3000, getIniFileFullPath().c_str());
		for (int i = 0; i < keys_count; i++)
			if (szBuffer[i] == '\0') szBuffer[i] = '\\';

		std::string sBuffer = szBuffer, szBuff;
		std::vector <float> keys_float_value;
		size_t first_splash = 0, next_splash = std::string::npos, unk = std::string::npos;
		while ((next_splash = sBuffer.find_first_of('\\')) != std::string::npos)
		{
			unk = sBuffer.find_first_of('=');
			szBuff = sBuffer.substr(first_splash, unk);
			if (!strcmp(szBuff.c_str(), key_name.c_str()))
				keys_float_value.push_back(std::stof(sBuffer.substr(unk + 1, next_splash - unk - 1).c_str()));
			sBuffer = sBuffer.substr(next_splash + 1, sBuffer.length());
		}

		return keys_float_value;
	};

	std::vector <std::string> getParams(std::string str) {
		std::vector <std::string> params;
		size_t start_ip = std::string::npos, end_ip = std::string::npos;
		while ((start_ip = str.find('"')) != std::string::npos)
		{
			end_ip = str.find('"', start_ip + 1);
			params.push_back(str.substr(start_ip + 1, end_ip - 1));
			str = str.erase(0, str.find('"', end_ip + 1));
		}
		return params;
	};

	std::vector <std::string> getParams(std::string str, char *delimiter) {
		std::vector <std::string> params;
		size_t start_ip = std::string::npos, end_ip = std::string::npos;
		while ((start_ip = str.find(delimiter)) != std::string::npos)
		{
			end_ip = str.find(delimiter, start_ip + 1);
			params.push_back(str.substr(start_ip + 1, end_ip - 1));
			str = str.erase(0, str.find(delimiter, end_ip + 1));
		}
		return params;
	};

	std::vector <std::string> getParams(std::string str, char *s_delimiter, char *e_delimiter) {
		size_t slen = strlen(s_delimiter), elen = strlen(s_delimiter);
		std::vector <std::string> params;
		size_t start_ip = std::string::npos, end_ip = std::string::npos;
		while ((start_ip = str.find(s_delimiter)) != std::string::npos)
		{
			end_ip = str.find(e_delimiter, start_ip + slen);
			params.push_back(str.substr(start_ip + slen, end_ip - elen));
			str = str.erase(0, str.find(s_delimiter, end_ip + slen));
		}
		return params;
	};

	void IniFile::setInteger(std::string section_name, std::string key_name, DWORD value) {
		if (!ini_file_exist()) return;

		WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::setFloat(std::string section_name, std::string key_name, float value) {
		if (!ini_file_exist()) return;

		WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::setString(std::string section_name, std::string key_name, std::string text) {
		if (!ini_file_exist()) return;

		WritePrivateProfileString(section_name.c_str(), key_name.c_str(), text.c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::setBoolean(std::string section_name, std::string key_name, bool value) {
		if (!ini_file_exist()) return;

		if (value) WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "true", getIniFileFullPath().c_str());
		else WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "false", getIniFileFullPath().c_str());
	};

	void IniFile::addInteger(std::string section_name, std::string key_name, DWORD value) {
		if (!ini_file_exist()) return;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::addFloat(std::string section_name, std::string key_name, float value) {
		if (!ini_file_exist()) return;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::addString(std::string section_name, std::string key_name, std::string text) {
		if (!ini_file_exist()) return;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), text.c_str(), getIniFileFullPath().c_str());
	};

	void IniFile::addBoolean(std::string section_name, std::string key_name, bool value) {
		if (!ini_file_exist()) return;
		if (!existKey(section_name, key_name))
			if (value) WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "true", getIniFileFullPath().c_str());
			else WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "false", getIniFileFullPath().c_str());
	};

	int IniFile::gwInteger(std::string section_name, std::string key_name, DWORD value) {
		if (!ini_file_exist()) return NULL;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
		return GetPrivateProfileInt(section_name.c_str(), key_name.c_str(), 0, getIniFileFullPath().c_str());
	};

	float IniFile::gwFloat(std::string section_name, std::string key_name, float value) {
		if (!ini_file_exist()) return NULL;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), std::to_string(value).c_str(), getIniFileFullPath().c_str());
		GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
		return std::stof(szBuffer);
	};

	std::string IniFile::gwString(std::string section_name, std::string key_name, std::string text) {
		if (!ini_file_exist()) return NULL;
		if (!existKey(section_name, key_name))
			WritePrivateProfileString(section_name.c_str(), key_name.c_str(), text.c_str(), getIniFileFullPath().c_str());
		GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
		return szBuffer;
	};

	bool IniFile::gwBoolean(std::string section_name, std::string key_name, bool value) {
		if (!ini_file_exist()) return false;
		if (!existKey(section_name, key_name))
			if (value) WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "true", getIniFileFullPath().c_str());
			else WritePrivateProfileString(section_name.c_str(), key_name.c_str(), "false", getIniFileFullPath().c_str());
			GetPrivateProfileString(section_name.c_str(), key_name.c_str(), NULL, szBuffer, sizeof(szBuffer), getIniFileFullPath().c_str());
			std::string str = (const char*)szBuffer;
			convToLowercase(&str);
			if (_stricmp("true", (char*)str.c_str()) == 0 || _stricmp("1", (char*)str.c_str()) == 0) return true;
			return false;
	};
private:
	char szBuffer[3000];
	std::string m_sIniFilePath;
	std::string m_sIniFileName;

	bool ini_file_exist() {
		WIN32_FIND_DATA FindFileData;
		HANDLE hFindIni;

		hFindIni = FindFirstFile(getIniFileFullPath().c_str(), &FindFileData);
		if (hFindIni != INVALID_HANDLE_VALUE)
			return true;

		return false;
	};

	bool create_new_ini_file() {
		if (!ini_file_exist())
		{
			FILE *fp = NULL;
			errno_t fp_er = fopen_s(&fp, getIniFileFullPath().c_str(), "w");
			if (!fp_er && fp != NULL)
				fclose(fp);

			return true;
		}
		return false;
	};

	void convToLowercase(std::string *str) {
		int sz = str->length();
		char ch[1024];
		memset(ch, 0, sizeof(ch));

		sprintf_s(ch, sizeof(ch), (char*)str->c_str());
		for (int i = 0; i < sz; i++)
		{
			if (ch[i] > 0x41 && ch[i] < 0x5a) ch[i] += 0x20;
			if (ch[i] > 0xc0 && ch[i] < 0xdf) ch[i] += 0x20;
		}

		*str = (const char*)ch;
	};
};

class ASIModule
{
	float						Version;
	DWORD						SAMPAddr;
	bool						InitPlugin;
	struct stSAMP_R1			*g_SAMP_R1;
	struct stChatInfo_R1		*g_Chat_R1;
	struct stSAMP_R3			*g_SAMP_R3;
	struct stChatInfo_R3		*g_Chat_R3;
	RakClientInterface			*g_RakClient;
	bool						UsedHooks;

	float GetSAMPVersion(void) {
		switch (reinterpret_cast<IMAGE_NT_HEADERS*>(SAMPAddr + reinterpret_cast<IMAGE_DOS_HEADER*>(SAMPAddr)->e_lfanew)->OptionalHeader.AddressOfEntryPoint) {
			case 0x31DF13: return 1.0f; // R1
			case 0xCC4D0:  return 3.0f; // R3
		}
		return 0.0f;
	};

	bool DataCompare(const BYTE* pData, const BYTE* pattern, const char* mask) {
		for (; *mask; ++mask, ++pData, ++pattern) if (*mask == 'x' && *pData != *pattern) return false;
		return !(*mask);
	};
public:
	template<typename T>ASIModule(T SampDLL, bool _UsedHooks = false) : UsedHooks(_UsedHooks)
	{ 
		g_RakClient = nullptr;
		g_SAMP_R1 = nullptr;
		g_SAMP_R3 = nullptr;
		g_Chat_R1 = nullptr;
		g_Chat_R3 = nullptr;
		InitPlugin = false;
		SAMPAddr = (DWORD)SampDLL;
	};

	~ASIModule(void) {
		if (UsedHooks) {
			if (Version == 1.0f || Version == 3.0f) {
				void *deleteHook = nullptr;
				if (Version == 1.0f) {
					deleteHook = g_SAMP_R1->pRakClientInterface;
					g_SAMP_R1->pRakClientInterface = g_RakClient;
					delete_hook(deleteHook);
				}
				else {
					deleteHook = g_SAMP_R3->pRakClientInterface;
					g_SAMP_R3->pRakClientInterface = g_RakClient;
					delete_hook(deleteHook);
				}
			}
		}
		g_RakClient = nullptr;
		g_SAMP_R1 = nullptr;
		g_SAMP_R3 = nullptr;
		g_Chat_R1 = nullptr;
		g_Chat_R3 = nullptr;
		InitPlugin = false;
		SAMPAddr = 0;
	};

	template<typename T>bool delete_hook(T* pT) {
		if (pT == nullptr) {
			return false;
		}
		delete pT;
		pT = nullptr;
		return true;
	};

	DWORD						GetSAMP(void) { return SAMPAddr; };

	DWORD						GetHookSAMP(void) { return Version == 1.0f ? (SAMPAddr + 0x03743D) : (SAMPAddr + 0x03A7ED); };

	RakClientInterface			*getRaknet(void) { return g_RakClient; };

	bool Init(void) {
		if (!InitPlugin) {
			Version = GetSAMPVersion();
			if (Version == 1.0f || Version == 3.0f) {
				if (Version == 1.0f) {
					g_SAMP_R1 = *(stSAMP_R1 **)(SAMPAddr + 0x21A0F8);
					if (g_SAMP_R1 == nullptr) return false;
					if (g_SAMP_R1->pRakClientInterface == nullptr) return false;
					g_Chat_R1 = *(stChatInfo_R1 **)(SAMPAddr + 0x21A0E4);
					if (g_Chat_R1 == nullptr) return false;
					g_RakClient = (RakClientInterface *)g_SAMP_R1->pRakClientInterface;
					if (UsedHooks) {
						g_SAMP_R1->pRakClientInterface = new RakClientInterface();
					}
				}
				else {
					g_SAMP_R3 = *(stSAMP_R3 **)(SAMPAddr + 0x26E8DC);
					if (g_SAMP_R3 == nullptr) return false;
					if (g_SAMP_R3->pRakClientInterface == nullptr) return false;
					g_Chat_R3 = *(stChatInfo_R3 **)(SAMPAddr + 0x26E8C8);
					if (g_Chat_R3 == nullptr) return false;
					g_RakClient = (RakClientInterface *)g_SAMP_R3->pRakClientInterface;
					if (UsedHooks) {
						g_SAMP_R3->pRakClientInterface = new RakClientInterface();
					}
				}
			}
			else {
				SAMPAddr = 0;
			}
			InitPlugin = true;
		}
		return InitPlugin;
	};

	void AddMessageToChat(D3DCOLOR cColor, const char *szMsg, ...) {
		if ((g_Chat_R1 == nullptr && g_Chat_R3 == nullptr) || szMsg == nullptr) return;
		void(__thiscall *AddToChatWindowBuffer) (const void *_this, int iType, char *szText, char *szPrefix, DWORD cColor, DWORD cPrefixColor) =
			(void(__thiscall *) (const void *, int, char *, char *, DWORD, DWORD)) (SAMPAddr + (Version == 1.0f ? 0x064010 : 0x067460));
		va_list ap;
		char MessagePrint[512];
		memset(MessagePrint, 0, 512);
		va_start(ap, szMsg);
		vsnprintf(MessagePrint, sizeof(MessagePrint) - 1, szMsg, ap);
		va_end(ap);
		return AddToChatWindowBuffer(Version == 1.0f ? ((const void *)g_Chat_R1) : ((const void *)g_Chat_R3), 8, MessagePrint, 0, cColor, 0);
	};

	void ShowTextLowpriority(unsigned int time, unsigned short flag, bool bPreviousBrief, const char *szMsg, ...)
	{
		if (szMsg == nullptr) return;
		if (strlen(szMsg) >= 256) return;
		va_list ap;
		char MessagePrint[512];
		memset(MessagePrint, 0, 512);
		va_start(ap, szMsg);
		vsnprintf(MessagePrint, sizeof(MessagePrint) - 1, szMsg, ap);
		va_end(ap);
		return ((void(__cdecl *)(char *, unsigned int, unsigned short, bool))0x69F1E0)(MessagePrint, time, flag, bPreviousBrief);
	};

	bool RegisterClientCommand(char *szCmd, CMDPROC pFunc)
	{
		DWORD SAMP_FUNC_ADDCLIENTCMD = Version == 1.0f ? 0x065AD0 : Version == 3.0f ? 0x069000 : 0;
		DWORD SAMP_CHAT_INPUT_INFO_OFFSET = Version == 1.0f ? 0x21A0E8 : Version == 3.0f ? 0x26E8CC : 0;
		if (SAMP_FUNC_ADDCLIENTCMD && SAMP_CHAT_INPUT_INFO_OFFSET && pFunc != nullptr && szCmd != nullptr)
		{
			stInputInfo *g_Input = *(stInputInfo **)(SAMPAddr + SAMP_CHAT_INPUT_INFO_OFFSET);
			if (g_Input == nullptr) return false;
			for (byte i = 0; i < 144; i++) if (!strcmp(szCmd, g_Input->szCMDNames[i])) return false;
			void(__thiscall *AddClientCommand) (const void *_this, char *szCommand, CMDPROC pFunc) = (void(__thiscall *) (const void *, char *, CMDPROC)) (SAMPAddr + SAMP_FUNC_ADDCLIENTCMD);
			AddClientCommand(g_Input, szCmd, pFunc);
			return true;
		}
		return false;
	};

	void DeleteClientCommand(char *szCmd, CMDPROC pFunc)
	{
		DWORD SAMP_CHAT_INPUT_INFO_OFFSET = Version == 1.0f ? 0x21A0E8 : Version == 3.0f ? 0x26E8CC : 0;
		if (SAMP_CHAT_INPUT_INFO_OFFSET && pFunc != nullptr && szCmd != nullptr)
		{
			stInputInfo *g_Input = *(stInputInfo **)(SAMPAddr + SAMP_CHAT_INPUT_INFO_OFFSET);
			if (g_Input == nullptr) return;
			for (byte i = 0; i < 144; i++)
			{
				if (g_Input->pCMDs[i] == pFunc && !strcmp(szCmd, g_Input->szCMDNames[i]))
				{
					memset(&g_Input->pCMDs[i], 0, 4);
					memset(g_Input->szCMDNames[i], 0, 33);
					memset(&g_Input->szCMDNames[i], 0, 4);
					break;
				}
			}
		}
		return;
	};

	bool GetServerName(const char *name, uint16_t port) {
		if (g_SAMP_R1 == nullptr && g_SAMP_R3 == nullptr) return false;
		if (Version == 1.0f || Version == 3.0f) {
			if (Version == 1.0f) {
				if (g_SAMP_R1->m_nPort == port) {
					return strstr(g_SAMP_R1->m_szHostname, name) != nullptr;
				}
			}
			else if (g_SAMP_R3->m_nPort == port) {
				return strstr(g_SAMP_R3->m_szHostname, name) != nullptr;
			}
		}
		return false;
	};

	bool SendRPC(int rpcId, BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
		if (g_RakClient == nullptr) {
			return false;
		}
		return g_RakClient->RPC(&rpcId, bitStream, priority, reliability, orderingChannel, shiftTimestamp);
	};

	template<typename T>T MemoryRead(int Memory, bool protect = true) // MemoryRead<unsigned int>(0x00000000);
	{
		T Value;
		if (protect) {
			DWORD oldProt = PAGE_EXECUTE_READWRITE;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
			Value = *(T*)(Memory);
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
		}
		else {
			Value = *(T*)(Memory);
		}
		return Value;
	};

	template<typename T>void SetMemory(int Memory, T Value, bool protect = true) // SetMemory(0x00000000, (uint8_t)0x00);
	{
		if (protect) {
			DWORD oldProt = PAGE_EXECUTE_READWRITE;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
			if (*(T*)(Memory) != Value) *(T*)(Memory) = Value;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
		}
		else {
			if (*(T*)(Memory) != Value) *(T*)(Memory) = Value;
		}
		return;
	};

	void SetMemory(void *address, void *bytes, int Size) // SetMemory((void*)0x00000000, (PBYTE)"\x00\x00\x00\x00\x00", 5);
	{
		DWORD oldProt = PAGE_EXECUTE_READWRITE;
		VirtualProtect(address, Size, oldProt, &oldProt);
		memcpy(address, bytes, Size);
		VirtualProtect(address, Size, oldProt, &oldProt);
		return;
	};

	void SetMemory(int Memory, uint8_t Value, int Size)  // SetMemory(0x00000000, (uint8_t)0x00, 5);
	{
		DWORD oldProt = PAGE_EXECUTE_READWRITE;
		VirtualProtect((LPVOID)(Memory), Size, oldProt, &oldProt);
		memset((int*)Memory, Value, Size);
		VirtualProtect((LPVOID)(Memory), Size, oldProt, &oldProt);
		return;
	};

	DWORD FindPattern(DWORD start_address, DWORD length, BYTE* pattern, char *mask) {
		for (DWORD i = 0; i < length; i++) if (DataCompare((BYTE*)(start_address + i), pattern, mask)) return (DWORD)(start_address + i);
		return 0;
	};
};