#pragma once
#include "main.h"
#pragma pack(push, 1)
struct stSAMP_R1
{
	void									*pUnk0;
	void									*pServerInfo;
	uint8_t									byteSpace[24];
	char									m_szHostAddress[257];
	char									m_szHostname[259];
	bool									bNametagStatus;
	uint32_t								m_nPort;
	uint32_t								ulMapIcons[100];
	int										iLanMode;
	int										iGameState;
	uint32_t								ulConnectTick;
	void									*pSettings;
	void									*pRakClientInterface;
	void									*pPools;
};

struct stSAMP_R3
{
	char									pad_0[44];
	RakClientInterface*						pRakClientInterface;
	char									m_szHostAddress[257];
	char									m_szHostname[257];
	bool									m_bDisableCollision;
	bool									m_bUpdateCameraTarget;
	bool									m_bNametagStatus;
	int										m_nPort;
	BOOL									m_bLanMode;
	uint32_t								ulMapIcons[100];
	int										iGameState;
	uint32_t								ulConnectTick;
	void									*pSettings;
	char									pad_2[5];
	void									*pPools;
};

struct stChatEntry
{
	__int32									m_timestamp;
	char									m_szPrefix[28];
	char									m_szText[144];
	char									unused[64];
	int										m_nType;
	D3DCOLOR								m_textColor;
	D3DCOLOR								m_prefixColor;
};

struct stChatInfo_R1
{
	int										pagesize;
	void									*pUnk;
	int										iChatWindowMode;
	uint8_t									bTimestamps;
	uint32_t								iLogFileExist;
	char									logFilePathChatLog[MAX_PATH + 1];
	void									*pGameUI; // CDXUTDialog
	void									*pEditBackground; // CDXUTEditBox
	void									*pDXUTScrollBar;
	D3DCOLOR								clTextColor;
	D3DCOLOR								clInfoColor;
	D3DCOLOR								clDebugColor;
	uint32_t								ulChatWindowBottom;

	struct stChatEntry						chatEntry[100];

	void									*m_pFontRenderer;
	ID3DXSprite								*m_pChatTextSprite;
	ID3DXSprite								*m_pSprite;
	IDirect3DDevice9						*m_pD3DDevice;
	int										m_iRenderMode; // 0 - Direct Mode (slow), 1 - Normal mode
	ID3DXRenderToSurface					*pID3DXRenderToSurface;
	IDirect3DTexture9						*m_pTexture;
	IDirect3DSurface9						*pSurface;
	D3DDISPLAYMODE							*pD3DDisplayMode;
	int										iUnk1[3];
	int										iUnk2; // smth related to drawing in direct mode
	int										m_iRedraw;
	int										m_nPrevScrollBarPosition;
	int										m_iFontSizeY;
	int										m_iTimestampWidth;
};

struct stChatInfo_R3
{
	unsigned int							m_nPageSize;
	char*									m_szLastMessage;
	int										m_nMode;
	bool									m_bTimestamps;
	BOOL									m_bDoesLogExist;
	char									m_szLogPath[261]; // MAX_PATH(+1)
	void									*m_pGameUi;
	void									*m_pEditbox;
	void									*m_pScrollbar;
	D3DCOLOR								m_textColor;  // 0xFFFFFFFF
	D3DCOLOR								m_infoColor;  // 0xFF88AA62
	D3DCOLOR								m_debugColor; // 0xFFA9C4E4
	long									m_nWindowBottom;

	struct stChatEntry						chatEntry[100];

	void									*m_pFontRenderer;
	ID3DXSprite								*m_pChatTextSprite;
	ID3DXSprite								*m_pSprite;
	IDirect3DDevice9						*m_pD3DDevice;
	BOOL									m_bRenderToSurface;
	ID3DXRenderToSurface					*pID3DXRenderToSurface;
	IDirect3DTexture9						*m_pTexture;
	IDirect3DSurface9						*pSurface;
#ifdef _d3d9TYPES_H_
	D3DDISPLAYMODE							m_displayMode;
#else
	unsigned int							m_displayMode[4];
#endif
	int										pad_[2];
	BOOL									m_bRedraw;
	long									m_nScrollbarPos;
	long									m_nCharHeight;
	long									m_nTimestampWidth;
};

typedef void(__cdecl *CMDPROC) (PCHAR);
struct stInputInfo
{
	void									*pD3DDevice;
	void									*pDXUTDialog;
	void									*pDXUTEditBox;
	CMDPROC									pCMDs[144];
	char									szCMDNames[144][33];
	int										iCMDCount;
	int										iInputEnabled;
	char									szInputBuffer[129];
	char									szRecallBufffer[10][129];
	char									szCurrentBuffer[129];
	int										iCurrentRecall;
	int										iTotalRecalls;
	CMDPROC									pszDefaultCMD;
};
#pragma pack(pop)

class ASIModule
{
	float						Version;
	DWORD						SAMPAddr;
	bool						InitPlugin;
	struct stSAMP_R1			*g_SAMP_R1;
	struct stChatInfo_R1		*g_Chat_R1;
	struct stSAMP_R3			*g_SAMP_R3;
	struct stChatInfo_R3		*g_Chat_R3;

	float GetSAMPVersion(void) {
		switch (reinterpret_cast<IMAGE_NT_HEADERS*>(SAMPAddr + reinterpret_cast<IMAGE_DOS_HEADER*>(SAMPAddr)->e_lfanew)->OptionalHeader.AddressOfEntryPoint) {
			case 0x31DF13: return 1.0f; // R1
			case 0xCC4D0:  return 3.0f; // R3
		}
		return 0.0f;
	};

	bool DataCompare(const BYTE* pData, const BYTE* pattern, const char* mask) {
		for (; *mask; ++mask, ++pData, ++pattern) if (*mask == 'x' && *pData != *pattern) return false;
		return !(*mask);
	};
public:
	RakClientInterface			*g_RakClient;
	template<typename T>ASIModule(T SampDLL)
	{ 
		g_RakClient = nullptr;
		g_SAMP_R1 = nullptr;
		g_SAMP_R3 = nullptr;
		g_Chat_R1 = nullptr;
		g_Chat_R3 = nullptr;
		InitPlugin = false;
		SAMPAddr = (DWORD)SampDLL;
	};

	template<typename T>bool delete_hook(T* pT) {
		if (pT == nullptr) {
			return false;
		}
		delete pT;
		pT = nullptr;
		return true;
	};

	DWORD GetSAMP(void) { return SAMPAddr; };

	DWORD GetHookSAMP(void) { return Version == 1.0f ? (SAMPAddr + 0x03743D) : (SAMPAddr + 0x03A7ED); };

	bool Init(void) {
		if (!InitPlugin) {
			Version = GetSAMPVersion();
			if (Version == 1.0f || Version == 3.0f) {
				if (Version == 1.0f) {
					g_SAMP_R1 = *(stSAMP_R1 **)(SAMPAddr + 0x21A0F8);
					if (g_SAMP_R1 == nullptr) return false;
					if (g_SAMP_R1->pRakClientInterface == nullptr) return false;
					g_Chat_R1 = *(stChatInfo_R1 **)(SAMPAddr + 0x21A0E4);
					if (g_Chat_R1 == nullptr) return false;
					g_RakClient = (RakClientInterface *)g_SAMP_R1->pRakClientInterface;
				}
				else {
					g_SAMP_R3 = *(stSAMP_R3 **)(SAMPAddr + 0x26E8DC);
					if (g_SAMP_R3 == nullptr) return false;
					if (g_SAMP_R3->pRakClientInterface == nullptr) return false;
					g_Chat_R3 = *(stChatInfo_R3 **)(SAMPAddr + 0x26E8C8);
					if (g_Chat_R3 == nullptr) return false;
					g_RakClient = (RakClientInterface *)g_SAMP_R3->pRakClientInterface;
				}
			}
			else {
				SAMPAddr = 0;
			}
			InitPlugin = true;
		}
		return InitPlugin;
	};

	void AddMessageToChat(D3DCOLOR cColor, const char *szMsg, ...) {
		if ((g_Chat_R1 == nullptr && g_Chat_R3 == nullptr) || szMsg == nullptr) return;
		void(__thiscall *AddToChatWindowBuffer) (const void *_this, int iType, char *szText, char *szPrefix, DWORD cColor, DWORD cPrefixColor) =
			(void(__thiscall *) (const void *, int, char *, char *, DWORD, DWORD)) (SAMPAddr + (Version == 1.0f ? 0x064010 : 0x067460));
		va_list ap;
		char MessagePrint[512];
		memset(MessagePrint, 0, 512);
		va_start(ap, szMsg);
		vsnprintf(MessagePrint, sizeof(MessagePrint) - 1, szMsg, ap);
		va_end(ap);
		return AddToChatWindowBuffer(Version == 1.0f ? ((const void *)g_Chat_R1) : ((const void *)g_Chat_R3), 8, MessagePrint, 0, cColor, 0);
	};

	void ShowTextLowpriority(unsigned int time, unsigned short flag, bool bPreviousBrief, const char *szMsg, ...)
	{
		if (szMsg == nullptr) return;
		if (strlen(szMsg) >= 256) return;
		va_list ap;
		char MessagePrint[512];
		memset(MessagePrint, 0, 512);
		va_start(ap, szMsg);
		vsnprintf(MessagePrint, sizeof(MessagePrint) - 1, szMsg, ap);
		va_end(ap);
		return ((void(__cdecl *)(char *, unsigned int, unsigned short, bool))0x69F1E0)(MessagePrint, time, flag, bPreviousBrief);
	};

	bool RegisterClientCommand(char *szCmd, CMDPROC pFunc)
	{
		DWORD SAMP_FUNC_ADDCLIENTCMD = Version == 1.0f ? 0x065AD0 : Version == 3.0f ? 0x069000 : 0;
		DWORD SAMP_CHAT_INPUT_INFO_OFFSET = Version == 1.0f ? 0x21A0E8 : Version == 3.0f ? 0x26E8CC : 0;
		if (SAMP_FUNC_ADDCLIENTCMD && SAMP_CHAT_INPUT_INFO_OFFSET && pFunc != nullptr && szCmd != nullptr)
		{
			stInputInfo *g_Input = *(stInputInfo **)(SAMPAddr + SAMP_CHAT_INPUT_INFO_OFFSET);
			if (g_Input == nullptr) return false;
			for (byte i = 0; i < 144; i++) if (!strcmp(szCmd, g_Input->szCMDNames[i])) return false;
			void(__thiscall *AddClientCommand) (const void *_this, char *szCommand, CMDPROC pFunc) = (void(__thiscall *) (const void *, char *, CMDPROC)) (SAMPAddr + SAMP_FUNC_ADDCLIENTCMD);
			AddClientCommand(g_Input, szCmd, pFunc);
			return true;
		}
		return false;
	};

	void DeleteClientCommand(char *szCmd, CMDPROC pFunc)
	{
		DWORD SAMP_CHAT_INPUT_INFO_OFFSET = Version == 1.0f ? 0x21A0E8 : Version == 3.0f ? 0x26E8CC : 0;
		if (SAMP_CHAT_INPUT_INFO_OFFSET && pFunc != nullptr && szCmd != nullptr)
		{
			stInputInfo *g_Input = *(stInputInfo **)(SAMPAddr + SAMP_CHAT_INPUT_INFO_OFFSET);
			if (g_Input == nullptr) return;
			for (byte i = 0; i < 144; i++)
			{
				if (g_Input->pCMDs[i] == pFunc && !strcmp(szCmd, g_Input->szCMDNames[i]))
				{
					memset(&g_Input->pCMDs[i], 0, 4);
					memset(g_Input->szCMDNames[i], 0, 33);
					memset(&g_Input->szCMDNames[i], 0, 4);
					break;
				}
			}
		}
		return;
	};

	bool GetServerName(const char *name, uint16_t port) {
		if (g_SAMP_R1 == nullptr && g_SAMP_R3 == nullptr) return false;
		if (Version == 1.0f || Version == 3.0f) {
			if (Version == 1.0f) {
				if (g_SAMP_R1->m_nPort == port) {
					return strstr(g_SAMP_R1->m_szHostname, name) != nullptr;
				}
			}
			else if (g_SAMP_R3->m_nPort == port) {
				return strstr(g_SAMP_R3->m_szHostname, name) != nullptr;
			}
		}
		return false;
	};

	bool SendRPC(int rpcId, BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
		if (g_RakClient == nullptr) {
			return false;
		}
		return g_RakClient->RPC(&rpcId, bitStream, priority, reliability, orderingChannel, shiftTimestamp);
	};

	template<typename T>T MemoryRead(int Memory, bool protect = true) // MemoryRead<unsigned int>(0x00000000);
	{
		T Value;
		if (protect) {
			DWORD oldProt = PAGE_EXECUTE_READWRITE;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
			Value = *(T*)(Memory);
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
		}
		else {
			Value = *(T*)(Memory);
		}
		return Value;
	};

	template<typename T>void SetMemory(int Memory, T Value, bool protect = true) // SetMemory(0x00000000, (uint8_t)0x00);
	{
		if (protect) {
			DWORD oldProt = PAGE_EXECUTE_READWRITE;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
			if (*(T*)(Memory) != Value) *(T*)(Memory) = Value;
			VirtualProtect((LPVOID)(Memory), sizeof(T), oldProt, &oldProt);
		}
		else {
			if (*(T*)(Memory) != Value) *(T*)(Memory) = Value;
		}
		return;
	};

	void SetMemory(void *address, void *bytes, int Size) // SetMemory((void*)0x00000000, (PBYTE)"\x00\x00\x00\x00\x00", 5);
	{
		DWORD oldProt = PAGE_EXECUTE_READWRITE;
		VirtualProtect(address, Size, oldProt, &oldProt);
		memcpy(address, bytes, Size);
		VirtualProtect(address, Size, oldProt, &oldProt);
		return;
	};

	void SetMemory(int Memory, uint8_t Value, int Size)  // SetMemory(0x00000000, (uint8_t)0x00, 5);
	{
		DWORD oldProt = PAGE_EXECUTE_READWRITE;
		VirtualProtect((LPVOID)(Memory), Size, oldProt, &oldProt);
		memset((int*)Memory, Value, Size);
		VirtualProtect((LPVOID)(Memory), Size, oldProt, &oldProt);
		return;
	};

	DWORD FindPattern(DWORD start_address, DWORD length, BYTE* pattern, char *mask) {
		for (DWORD i = 0; i < length; i++) if (DataCompare((BYTE*)(start_address + i), pattern, mask)) return (DWORD)(start_address + i);
		return 0;
	};
};