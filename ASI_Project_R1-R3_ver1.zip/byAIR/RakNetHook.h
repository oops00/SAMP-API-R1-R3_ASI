#pragma once
std::vector<bool(CALLBACK*)(unsigned char, RPCParameters *)>listHandleRPCPacket;
std::vector<bool(CALLBACK*)(int, BitStream*, PacketPriority, PacketReliability, char, bool)>listSendRPC;
std::vector<bool(CALLBACK*)(BitStream*, PacketPriority, PacketReliability, char)>listSendPacket;
std::vector<bool(CALLBACK*)(Packet*)>listRecive;

// incomingRPC
bool HandleRPCPacketFunc(unsigned char id, RPCParameters *rpcParams)
{
	for (size_t i = 0; i < listHandleRPCPacket.size(); ++i) {
		if (!listHandleRPCPacket[i](id, rpcParams)) {
			return false;
		}
	}
	//================HOOK=================
	if (rpcParams->numberOfBitsOfData > 0)
	{
		//=============RPC=============
		//-------------CODE------------
		//=============================
	}
	//=====================================
	return true;
};

// outcomingRPC
bool RakClientInterface::RPC(int* uniqueID, BitStream *parameters, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
	if (uniqueID != nullptr) {
		for (size_t i = 0; i < listSendRPC.size(); ++i) {
			if (!listSendRPC[i](*uniqueID, parameters, priority, reliability, orderingChannel, shiftTimestamp)) {
				return false;
			}
		}
		//=============RPC=============
		//-------------CODE------------
		//=============================
	}
	return pSAMP->g_RakClient->RPC(uniqueID, parameters, priority, reliability, orderingChannel, shiftTimestamp);
};

// outcomingPacket
bool RakClientInterface::Send(BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel) {
	if (bitStream != nullptr) {
		for (size_t i = 0; i < listSendPacket.size(); ++i) {
			if (!listSendPacket[i](bitStream, priority, reliability, orderingChannel)) {
				return false;
			}
		}
		//=============Packet=============
		//--------------CODE--------------
		//================================
	}
	return pSAMP->g_RakClient->Send(bitStream, priority, reliability, orderingChannel);
};

// incomingPacket
Packet *RakClientInterface::Receive(void) {
	Packet *p = pSAMP->g_RakClient->Receive();
	while (p != nullptr)
	{
		bool result = true;
		for (size_t i = 0; i < listRecive.size(); ++i) {
			if (!listRecive[i](p)) {
				result = false;
				break;
			}
		}
		if (result) break;
		//=============Packet=============
		//--------------CODE--------------
		//================================
		pSAMP->g_RakClient->DeallocatePacket(p);
	}
	return p;
};

bool RakClientInterface::Connect(const char* host, unsigned short serverPort, unsigned short clientPort, unsigned int depreciated, int threadSleepTimer) {
	return pSAMP->g_RakClient->Connect(host, serverPort, clientPort, depreciated, threadSleepTimer);
};

void RakClientInterface::Disconnect(unsigned int blockDuration, unsigned char orderingChannel) {
	return pSAMP->g_RakClient->Disconnect(blockDuration, orderingChannel);
};

void RakClientInterface::InitializeSecurity(const char *privKeyP, const char *privKeyQ) {
	return pSAMP->g_RakClient->InitializeSecurity(privKeyP, privKeyQ);
};

void RakClientInterface::SetPassword(const char *_password) {
	return pSAMP->g_RakClient->SetPassword(_password);
};

bool RakClientInterface::HasPassword(void) const {
	return pSAMP->g_RakClient->HasPassword();
};

bool RakClientInterface::Send(const char *data, const int length, PacketPriority priority, PacketReliability reliability, char orderingChannel) {
	return pSAMP->g_RakClient->Send(data, length, priority, reliability, orderingChannel);
};

void RakClientInterface::DeallocatePacket(Packet *packet) {
	return pSAMP->g_RakClient->DeallocatePacket(packet);
};

void RakClientInterface::PingServer(void) {
	return pSAMP->g_RakClient->PingServer();
};

void RakClientInterface::PingServer(const char* host, unsigned short serverPort, unsigned short clientPort, bool onlyReplyOnAcceptingConnections) {
	return pSAMP->g_RakClient->PingServer(host, serverPort, clientPort, onlyReplyOnAcceptingConnections);
};

int RakClientInterface::GetAveragePing(void) {
	return pSAMP->g_RakClient->GetAveragePing();
};

int RakClientInterface::GetLastPing(void) const {
	return pSAMP->g_RakClient->GetLastPing();
};

int RakClientInterface::GetLowestPing(void) const {
	return pSAMP->g_RakClient->GetLowestPing();
};

int RakClientInterface::GetPlayerPing(const PlayerID playerId) {
	return pSAMP->g_RakClient->GetPlayerPing(playerId);
};

void RakClientInterface::StartOccasionalPing(void) {
	return pSAMP->g_RakClient->StartOccasionalPing();
};

void RakClientInterface::StopOccasionalPing(void) {
	return pSAMP->g_RakClient->StopOccasionalPing();
};

bool RakClientInterface::IsConnected(void) const {
	return pSAMP->g_RakClient->IsConnected();
};

unsigned int RakClientInterface::GetSynchronizedRandomInteger(void) const {
	return pSAMP->g_RakClient->GetSynchronizedRandomInteger();
};

bool RakClientInterface::GenerateCompressionLayer(unsigned int inputFrequencyTable[256], bool inputLayer) {
	return pSAMP->g_RakClient->GenerateCompressionLayer(inputFrequencyTable, inputLayer);
};

bool RakClientInterface::DeleteCompressionLayer(bool inputLayer) {
	return pSAMP->g_RakClient->DeleteCompressionLayer(inputLayer);
};

void RakClientInterface::RegisterAsRemoteProcedureCall(int* uniqueID, void(*functionPointer) (RPCParameters *rpcParms)) {
	return pSAMP->g_RakClient->RegisterAsRemoteProcedureCall(uniqueID, functionPointer);
};

void RakClientInterface::RegisterClassMemberRPC(int* uniqueID, void *functionPointer) {
	return pSAMP->g_RakClient->RegisterClassMemberRPC(uniqueID, functionPointer);
};

void RakClientInterface::UnregisterAsRemoteProcedureCall(int* uniqueID) {
	return pSAMP->g_RakClient->UnregisterAsRemoteProcedureCall(uniqueID);
};

bool RakClientInterface::RPC(int* uniqueID, const char *data, unsigned int bitLength, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
	return pSAMP->g_RakClient->RPC(uniqueID, data, bitLength, priority, reliability, orderingChannel, shiftTimestamp);
};

void RakClientInterface::SetTrackFrequencyTable(bool b) {
	return pSAMP->g_RakClient->SetTrackFrequencyTable(b);
};

bool RakClientInterface::GetSendFrequencyTable(unsigned int outputFrequencyTable[256]) {
	return pSAMP->g_RakClient->GetSendFrequencyTable(outputFrequencyTable);
};

float RakClientInterface::GetCompressionRatio(void) const {
	return pSAMP->g_RakClient->GetCompressionRatio();
};

float RakClientInterface::GetDecompressionRatio(void) const {
	return pSAMP->g_RakClient->GetDecompressionRatio();
};

void RakClientInterface::AttachPlugin(void *messageHandler) {
	return pSAMP->g_RakClient->AttachPlugin(messageHandler);
};

void RakClientInterface::DetachPlugin(void *messageHandler) {
	return pSAMP->g_RakClient->DetachPlugin(messageHandler);
};

BitStream * RakClientInterface::GetStaticServerData(void) {
	return pSAMP->g_RakClient->GetStaticServerData();
};

void RakClientInterface::SetStaticServerData(const char *data, const int length) {
	return pSAMP->g_RakClient->SetStaticServerData(data, length);
};

BitStream * RakClientInterface::GetStaticClientData(const PlayerID playerId) {
	return pSAMP->g_RakClient->GetStaticClientData(playerId);
};

void RakClientInterface::SetStaticClientData(const PlayerID playerId, const char *data, const int length) {
	return pSAMP->g_RakClient->SetStaticClientData(playerId, data, length);
};

void RakClientInterface::SendStaticClientDataToServer(void) {
	return pSAMP->g_RakClient->SendStaticClientDataToServer();
};

PlayerID RakClientInterface::GetServerID(void) const {
	return pSAMP->g_RakClient->GetServerID();
};

PlayerID RakClientInterface::GetPlayerID(void) const {
	return pSAMP->g_RakClient->GetPlayerID();
};

PlayerID RakClientInterface::GetInternalID(void) const {
	return pSAMP->g_RakClient->GetInternalID();
};

const char* RakClientInterface::PlayerIDToDottedIP(const PlayerID playerId) const {
	return pSAMP->g_RakClient->PlayerIDToDottedIP(playerId);
};

void RakClientInterface::PushBackPacket(Packet *packet, bool pushAtHead) {
	return pSAMP->g_RakClient->PushBackPacket(packet, pushAtHead);
};

void RakClientInterface::SetRouterInterface(void *routerInterface) {
	return pSAMP->g_RakClient->SetRouterInterface(routerInterface);
};

void RakClientInterface::RemoveRouterInterface(void *routerInterface) {
	return pSAMP->g_RakClient->RemoveRouterInterface(routerInterface);
};

void RakClientInterface::SetTimeoutTime(RakNetTime timeMS) {
	return pSAMP->g_RakClient->SetTimeoutTime(timeMS);
};

bool RakClientInterface::SetMTUSize(int size) {
	return pSAMP->g_RakClient->SetMTUSize(size);
};

int RakClientInterface::GetMTUSize(void) const {
	return pSAMP->g_RakClient->GetMTUSize();
};

void RakClientInterface::AllowConnectionResponseIPMigration(bool allow) {
	return pSAMP->g_RakClient->AllowConnectionResponseIPMigration(allow);
};

void RakClientInterface::AdvertiseSystem(const char *host, unsigned short remotePort, const char *data, int dataLength) {
	return pSAMP->g_RakClient->AdvertiseSystem(host, remotePort, data, dataLength);
};

RakNetStatisticsStruct* const RakClientInterface::GetStatistics(void) {
	return pSAMP->g_RakClient->GetStatistics();
};

void RakClientInterface::ApplyNetworkSimulator(double maxSendBPS, unsigned short minExtraPing, unsigned short extraPingVariance) {
	return pSAMP->g_RakClient->ApplyNetworkSimulator(maxSendBPS, minExtraPing, extraPingVariance);
};

bool RakClientInterface::IsNetworkSimulatorActive(void) {
	return pSAMP->g_RakClient->IsNetworkSimulatorActive();
};

PlayerIndex RakClientInterface::GetPlayerIndex(void) {
	return pSAMP->g_RakClient->GetPlayerIndex();
};

bool RakClientInterface::RPC_(int* uniqueID, BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp, NetworkID networkID) {
	return pSAMP->g_RakClient->RPC_(uniqueID, bitStream, priority, reliability, orderingChannel, shiftTimestamp, networkID);
};