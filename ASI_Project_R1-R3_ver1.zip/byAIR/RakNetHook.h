#pragma once
std::vector<bool(CALLBACK*)(unsigned char, RPCParameters *)>listHandleRPCPacket;
std::vector<bool(CALLBACK*)(int, BitStream*, PacketPriority, PacketReliability, char, bool)>listSendRPC;
std::vector<bool(CALLBACK*)(BitStream*, PacketPriority, PacketReliability, char)>listSendPacket;
std::vector<bool(CALLBACK*)(Packet*)>listRecive;

// incomingRPC
bool HandleRPCPacketFunc(unsigned char id, RPCParameters *rpcParams)
{
	for (size_t i = 0; i < listHandleRPCPacket.size(); ++i) {
		if (!listHandleRPCPacket[i](id, rpcParams)) {
			return false;
		}
	}
	//================HOOK=================
	if (rpcParams->numberOfBitsOfData >= 8)
	{
		//=============RPC=============
		// BitStream bs(rpcParams->input, rpcParams->numberOfBitsOfData / 8, false);
		//=============================
	}
	//=====================================
	return true;
};

// outcomingRPC
bool RakClientInterface::RPC(int* uniqueID, BitStream *parameters, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
	if (uniqueID != nullptr) {
		for (size_t i = 0; i < listSendRPC.size(); ++i) {
			if (!listSendRPC[i](*uniqueID, parameters, priority, reliability, orderingChannel, shiftTimestamp)) {
				return false;
			}
		}
		//=============RPC=============
		//-------------CODE------------
		//=============================
	}
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RPC(uniqueID, parameters, priority, reliability, orderingChannel, shiftTimestamp);
		}
	}
	return false;
};

// outcomingPacket
bool RakClientInterface::Send(BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel) {
	if (bitStream != nullptr) {
		for (size_t i = 0; i < listSendPacket.size(); ++i) {
			if (!listSendPacket[i](bitStream, priority, reliability, orderingChannel)) {
				return false;
			}
		}
		//=============Packet=============
		//--------------CODE--------------
		//================================
	}
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->Send(bitStream, priority, reliability, orderingChannel);
		}
	}
	return false;
};

// incomingPacket
Packet *RakClientInterface::Receive(void) {
	Packet *p;
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			while (p = pSAMP->getRaknet()->Receive())
			{
				bool result = true;
				for (size_t i = 0; i < listRecive.size(); ++i) {
					if (!listRecive[i](p)) {
						result = false;
						break;
					}
				}
				//=============Packet=============
				// BitStream bs((unsigned char *)p->data, p->length, false);
				//================================
				if (result) break;
				pSAMP->getRaknet()->DeallocatePacket(p);
			}
			return p;
		}
	}
	return nullptr;
};

bool RakClientInterface::Connect(const char* host, unsigned short serverPort, unsigned short clientPort, unsigned int depreciated, int threadSleepTimer) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->Connect(host, serverPort, clientPort, depreciated, threadSleepTimer);
		}
	}
	return false;
};

void RakClientInterface::Disconnect(unsigned int blockDuration, unsigned char orderingChannel) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->Disconnect(blockDuration, orderingChannel);
		}
	}
	return;
};

void RakClientInterface::InitializeSecurity(const char *privKeyP, const char *privKeyQ) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->InitializeSecurity(privKeyP, privKeyQ);
		}
	}
	return;
};

void RakClientInterface::SetPassword(const char *_password) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetPassword(_password);
		}
	}
	return;
};

bool RakClientInterface::HasPassword(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->HasPassword();
		}
	}
	return false;
};

bool RakClientInterface::Send(const char *data, const int length, PacketPriority priority, PacketReliability reliability, char orderingChannel) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->Send(data, length, priority, reliability, orderingChannel);
		}
	}
	return false;
};

void RakClientInterface::DeallocatePacket(Packet *packet) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->DeallocatePacket(packet);
		}
	}
	return;
};

void RakClientInterface::PingServer(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->PingServer();
		}
	}
	return;
};

void RakClientInterface::PingServer(const char* host, unsigned short serverPort, unsigned short clientPort, bool onlyReplyOnAcceptingConnections) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->PingServer(host, serverPort, clientPort, onlyReplyOnAcceptingConnections);
		}
	}
	return;
};

int RakClientInterface::GetAveragePing(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetAveragePing();
		}
	}
	return 0;
};

int RakClientInterface::GetLastPing(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetLastPing();
		}
	}
	return 0;
};

int RakClientInterface::GetLowestPing(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetLowestPing();
		}
	}
	return 0;
};

int RakClientInterface::GetPlayerPing(const PlayerID playerId) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetPlayerPing(playerId);
		}
	}
	return 0;
};

void RakClientInterface::StartOccasionalPing(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->StartOccasionalPing();
		}
	}
	return;
};

void RakClientInterface::StopOccasionalPing(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->StopOccasionalPing();
		}
	}
	return;
};

bool RakClientInterface::IsConnected(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->IsConnected();
		}
	}
	return false;
};

unsigned int RakClientInterface::GetSynchronizedRandomInteger(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetSynchronizedRandomInteger();
		}
	}
	return 0;
};

bool RakClientInterface::GenerateCompressionLayer(unsigned int inputFrequencyTable[256], bool inputLayer) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GenerateCompressionLayer(inputFrequencyTable, inputLayer);
		}
	}
	return false;
};

bool RakClientInterface::DeleteCompressionLayer(bool inputLayer) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->DeleteCompressionLayer(inputLayer);
		}
	}
	return false;
};

void RakClientInterface::RegisterAsRemoteProcedureCall(int* uniqueID, void(*functionPointer) (RPCParameters *rpcParms)) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RegisterAsRemoteProcedureCall(uniqueID, functionPointer);
		}
	}
	return;
};

void RakClientInterface::RegisterClassMemberRPC(int* uniqueID, void *functionPointer) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RegisterClassMemberRPC(uniqueID, functionPointer);
		}
	}
	return;
};

void RakClientInterface::UnregisterAsRemoteProcedureCall(int* uniqueID) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->UnregisterAsRemoteProcedureCall(uniqueID);
		}
	}
	return;
};

bool RakClientInterface::RPC(int* uniqueID, const char *data, unsigned int bitLength, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RPC(uniqueID, data, bitLength, priority, reliability, orderingChannel, shiftTimestamp);
		}
	}
	return false;
};

void RakClientInterface::SetTrackFrequencyTable(bool b) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetTrackFrequencyTable(b);
		}
	}
	return;
};

bool RakClientInterface::GetSendFrequencyTable(unsigned int outputFrequencyTable[256]) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetSendFrequencyTable(outputFrequencyTable);
		}
	}
	return false;
};

float RakClientInterface::GetCompressionRatio(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetCompressionRatio();
		}
	}
	return 0.0f;
};

float RakClientInterface::GetDecompressionRatio(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetDecompressionRatio();
		}
	}
	return 0.0f;
};

void RakClientInterface::AttachPlugin(void *messageHandler) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->AttachPlugin(messageHandler);
		}
	}
	return;
};

void RakClientInterface::DetachPlugin(void *messageHandler) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->DetachPlugin(messageHandler);
		}
	}
	return;
};

BitStream * RakClientInterface::GetStaticServerData(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetStaticServerData();
		}
	}
	return nullptr;
};

void RakClientInterface::SetStaticServerData(const char *data, const int length) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetStaticServerData(data, length);
		}
	}
	return;
};

BitStream * RakClientInterface::GetStaticClientData(const PlayerID playerId) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetStaticClientData(playerId);
		}
	}
	return nullptr;
};

void RakClientInterface::SetStaticClientData(const PlayerID playerId, const char *data, const int length) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetStaticClientData(playerId, data, length);
		}
	}
	return;
};

void RakClientInterface::SendStaticClientDataToServer(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SendStaticClientDataToServer();
		}
	}
	return;
};

PlayerID RakClientInterface::GetServerID(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetServerID();
		}
	}
	const PlayerID st;
	return st;
};

PlayerID RakClientInterface::GetPlayerID(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetPlayerID();
		}
	}
	const PlayerID st;
	return st;
};

PlayerID RakClientInterface::GetInternalID(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetInternalID();
		}
	}
	const PlayerID st;
	return st;
};

const char* RakClientInterface::PlayerIDToDottedIP(const PlayerID playerId) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->PlayerIDToDottedIP(playerId);
		}
	}
	return nullptr;
};

void RakClientInterface::PushBackPacket(Packet *packet, bool pushAtHead) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->PushBackPacket(packet, pushAtHead);
		}
	}
	return;
};

void RakClientInterface::SetRouterInterface(void *routerInterface) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetRouterInterface(routerInterface);
		}
	}
	return;
};

void RakClientInterface::RemoveRouterInterface(void *routerInterface) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RemoveRouterInterface(routerInterface);
		}
	}
	return;
};

void RakClientInterface::SetTimeoutTime(RakNetTime timeMS) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetTimeoutTime(timeMS);
		}
	}
	return;
};

bool RakClientInterface::SetMTUSize(int size) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->SetMTUSize(size);
		}
	}
	return false;
};

int RakClientInterface::GetMTUSize(void) const {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetMTUSize();
		}
	}
	return 0;
};

void RakClientInterface::AllowConnectionResponseIPMigration(bool allow) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->AllowConnectionResponseIPMigration(allow);
		}
	}
	return;
};

void RakClientInterface::AdvertiseSystem(const char *host, unsigned short remotePort, const char *data, int dataLength) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->AdvertiseSystem(host, remotePort, data, dataLength);
		}
	}
	return;
};

RakNetStatisticsStruct* const RakClientInterface::GetStatistics(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetStatistics();
		}
	}
	return nullptr;
};

void RakClientInterface::ApplyNetworkSimulator(double maxSendBPS, unsigned short minExtraPing, unsigned short extraPingVariance) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->ApplyNetworkSimulator(maxSendBPS, minExtraPing, extraPingVariance);
		}
	}
	return;
};

bool RakClientInterface::IsNetworkSimulatorActive(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->IsNetworkSimulatorActive();
		}
	}
	return false;
};

PlayerIndex RakClientInterface::GetPlayerIndex(void) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->GetPlayerIndex();
		}
	}
	return 0;
};

bool RakClientInterface::RPC_(int* uniqueID, BitStream *bitStream, PacketPriority priority, PacketReliability reliability, char orderingChannel, bool shiftTimestamp, NetworkID networkID) {
	if (pSAMP != nullptr) {
		if (pSAMP->getRaknet() != nullptr) {
			return pSAMP->getRaknet()->RPC_(uniqueID, bitStream, priority, reliability, orderingChannel, shiftTimestamp, networkID);
		}
	}
	return false;
};