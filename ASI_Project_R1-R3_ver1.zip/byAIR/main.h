#pragma once
#include <string>
#include <vector>
#include <d3d9.h>
#include <d3dx9.h>
#include "UsedHooks.h"
#include "RakNet.h"
#include "SAMP.h"
extern ASIModule *pSAMP;
#include "RakNetHook.h"