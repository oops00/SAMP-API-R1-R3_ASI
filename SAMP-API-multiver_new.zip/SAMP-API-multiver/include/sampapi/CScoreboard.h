#pragma once
#include "sampapi/0.3.7-R1/CScoreboard.h"
#include "sampapi/0.3.7-R3-1/CScoreboard.h"
