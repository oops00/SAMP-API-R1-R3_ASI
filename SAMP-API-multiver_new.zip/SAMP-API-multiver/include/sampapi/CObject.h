#pragma once
#include "sampapi/0.3.7-R1/CObject.h"
#include "sampapi/0.3.7-R3-1/CObject.h"
