#pragma once
#include "sampapi/0.3.7-R1/CPlayerInfo.h"
#include "sampapi/0.3.7-R3-1/CPlayerInfo.h"
