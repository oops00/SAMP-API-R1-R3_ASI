#pragma once
#include "sampapi/0.3.7-R1/CTextDrawPool.h"
#include "sampapi/0.3.7-R3-1/CTextDrawPool.h"
