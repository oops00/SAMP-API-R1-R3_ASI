#pragma once
#include "sampapi/0.3.7-R1/CAudio.h"
#include "sampapi/0.3.7-R3-1/CAudio.h"
