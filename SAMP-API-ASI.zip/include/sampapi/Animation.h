#pragma once
#include "sampapi/0.3.7-R1/Animation.h"
#include "sampapi/0.3.7-R3-1/Animation.h"
