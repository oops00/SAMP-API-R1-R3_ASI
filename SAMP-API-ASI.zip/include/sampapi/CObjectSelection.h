#pragma once
#include "sampapi/0.3.7-R1/CObjectSelection.h"
#include "sampapi/0.3.7-R3-1/CObjectSelection.h"
