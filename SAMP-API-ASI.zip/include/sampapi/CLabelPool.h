#pragma once
#include "sampapi/0.3.7-R1/CLabelPool.h"
#include "sampapi/0.3.7-R3-1/CLabelPool.h"
