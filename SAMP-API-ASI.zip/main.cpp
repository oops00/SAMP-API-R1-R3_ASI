#include <Windows.h>

void PluginInit(void) {
	while (!GetModuleHandleA("SAMP.DLL")) {
		Sleep(100);
	}
	return ExitThread(0); // FreeLibraryAndExitThread
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
	switch (fdwReason) {
		case DLL_PROCESS_DETACH:
			break;
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hinstDLL);
			CreateThread(0, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(PluginInit), 0, 0, 0);
			break;
		default:
			break;
	}
	return TRUE;
};