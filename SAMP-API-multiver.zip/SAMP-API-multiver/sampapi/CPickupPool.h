#pragma once

#include "src/0.3.7-R1/CPickupPool.h"
#include "src/0.3.7-R3-1/CPickupPool.h"
