#pragma once

#include "src/0.3.7-R1/DebugScript.h"
#include "src/0.3.7-R3-1/DebugScript.h"
