#pragma once

#include "src/0.3.7-R1/CLabelPool.h"
#include "src/0.3.7-R3-1/CLabelPool.h"
