#pragma once

#include "src/0.3.7-R1/CDialog.h"
#include "src/0.3.7-R3-1/CDialog.h"
