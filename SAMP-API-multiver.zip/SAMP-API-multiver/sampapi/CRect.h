#pragma once

#include "src/common/CRect.h"
