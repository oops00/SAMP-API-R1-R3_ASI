#include <Windows.h>
#include "sampapi\CGame.h"
#include "sampapi\CChat.h"
#include "sampapi\CDialog.h"
#include "sampapi\CInput.h"
#include "sampapi\CNetGame.h"
#include "sampapi\CPed.h"
#include "sampapi\CRemotePlayer.h"

float GetSAMPVersion(DWORD &SAMPAddr) {
	switch (reinterpret_cast<IMAGE_NT_HEADERS*>(SAMPAddr + reinterpret_cast<IMAGE_DOS_HEADER*>(SAMPAddr)->e_lfanew)->OptionalHeader.AddressOfEntryPoint) {
		case 0x31DF13: return 1.0f; // R1
		case 0xCC4D0:  return 3.0f; // R3
		case 0xCBCB0:  return 4.0f; // R4
		case 0xFDB60:  return 3.1f; // 0.3DL-R1
	}
	return 0.0f;
};

void mainFunc(void) {
	// �������� SA-MP
	DWORD SAMPAddr = 0;
	do {
		Sleep(100);
		SAMPAddr = (DWORD)GetModuleHandle("samp.dll");
	} while (!SAMPAddr);
	//==============
	float isSAMPVersion = GetSAMPVersion(SAMPAddr); // ����������� ������ ����� 
	if (isSAMPVersion == 1.0f) {
		sampapi::v037r1::CGame *g_Game = nullptr;
		sampapi::v037r1::CChat *g_Chat = nullptr;
		sampapi::v037r1::CDialog *g_Dialog = nullptr;
		sampapi::v037r1::CInput *g_Input = nullptr;
		sampapi::v037r1::CNetGame *g_NetGame = nullptr;
		sampapi::v037r1::CPed *g_CPed = nullptr;
		do { g_Game = sampapi::v037r1::RefGame(); Sleep(10); } while (g_Game == nullptr);
		do { g_Chat = sampapi::v037r1::RefChat(); Sleep(10); } while (g_Chat == nullptr);
		do { g_Dialog = sampapi::v037r1::RefDialog(); Sleep(10); } while (g_Dialog == nullptr);
		do { g_Input = sampapi::v037r1::RefInputBox(); Sleep(10); } while (g_Input == nullptr);
		do { g_NetGame = sampapi::v037r1::RefNetGame(); Sleep(10); } while (g_NetGame == nullptr);
		do { g_CPed = g_Game->m_pPlayerPed; Sleep(10); } while (g_CPed == nullptr);
	} else if (isSAMPVersion == 3.0f) {
		sampapi::v037r3::CGame *g_Game = nullptr;
		sampapi::v037r3::CChat *g_Chat = nullptr;
		sampapi::v037r3::CDialog *g_Dialog = nullptr;
		sampapi::v037r3::CInput *g_Input = nullptr;
		sampapi::v037r3::CNetGame *g_NetGame = nullptr;
		sampapi::v037r3::CPed *g_CPed = nullptr;
		do { g_Game = sampapi::v037r3::RefGame(); Sleep(10); } while (g_Game == nullptr);
		do { g_Chat = sampapi::v037r3::RefChat(); Sleep(10); } while (g_Chat == nullptr);
		do { g_Dialog = sampapi::v037r3::RefDialog(); Sleep(10); } while (g_Dialog == nullptr);
		do { g_Input = sampapi::v037r3::RefInputBox(); Sleep(10); } while (g_Input == nullptr);
		do { g_NetGame = sampapi::v037r3::RefNetGame(); Sleep(10); } while (g_NetGame == nullptr);
		do { g_CPed = g_Game->m_pPlayerPed; Sleep(10); } while (g_CPed == nullptr);
	}
	return ExitThread(0);
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
	if (fdwReason == DLL_PROCESS_ATTACH) {
		DisableThreadLibraryCalls(hinstDLL);
		CreateThread(0, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(mainFunc), 0, 0, 0);
	}
	return TRUE;
};