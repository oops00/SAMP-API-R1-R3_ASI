#pragma once
#include "sampapi/0.3.7-R1/CActor.h"
#include "sampapi/0.3.7-R3-1/CActor.h"
#include "sampapi/0.3.7-R5-1/CActor.h"
