#pragma once
#include "sampapi/0.3.7-R1/CMenuPool.h"
#include "sampapi/0.3.7-R3-1/CMenuPool.h"
#include "sampapi/0.3.7-R5-1/CMenuPool.h"
